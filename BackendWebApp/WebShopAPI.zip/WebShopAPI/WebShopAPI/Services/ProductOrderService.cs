﻿using WebShopAPI.Dto;
using WebShopAPI.Interfaces;

namespace WebShopAPI.Services
{
    public class ProductOrderService : IProductOrderService
    {
        public ProductOrderDto AddProductOrder(ProductOrderDto newProductOrder)
        {
            throw new NotImplementedException();
        }

        public bool DeleteProductOrder(int id)
        {
            throw new NotImplementedException();
        }

        public ProductOrderDto GetProductOrder(int id)
        {
            throw new NotImplementedException();
        }

        public List<ProductOrderDto> GetProductOrders()
        {
            throw new NotImplementedException();
        }

        public ProductOrderDto UpdateProductOrder(int id, ProductOrderDto newProductOrder)
        {
            throw new NotImplementedException();
        }
    }
}

﻿namespace WebShopAPI.Dto
{
    public class OrderEditDto
    {
        public int OrderId { get; set; }
        public string Status { get; set; }
    }
}
